// @deno-types="https://github.com/DefinitelyTyped/DefinitelyTyped/raw/master/types/react-dom/index.d.ts"
export { render } from 'https://cdn.esm.sh/v43/react-dom@17.0.2/es2020/react-dom.js'
